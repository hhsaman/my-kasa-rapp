while true
do
echo "Starting Asta-Md!"
node .
done